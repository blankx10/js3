// 公共交互脚本：导航、轮播、筛选、标签切换、弹窗与工具功能

const mobileNavToggle = document.querySelector('[data-nav-toggle]');
const mobileNav = document.querySelector('[data-mobile-nav]');

if (mobileNavToggle && mobileNav) {
  mobileNavToggle.addEventListener('click', () => {
    mobileNav.classList.toggle('hidden');
  });
}

// 轮播图
const slides = Array.from(document.querySelectorAll('.hero-slide'));
const dots = Array.from(document.querySelectorAll('.dot'));
let currentSlide = 0;

function showSlide(index) {
  currentSlide = (index + slides.length) % slides.length;
  slides.forEach((slide, idx) => {
    slide.classList.toggle('active', idx === currentSlide);
  });
  dots.forEach((dot, idx) => {
    dot.classList.toggle('active', idx === currentSlide);
  });
}

if (slides.length && dots.length) {
  setInterval(() => showSlide(currentSlide + 1), 5000);
  dots.forEach((dot) => {
    dot.addEventListener('click', () => showSlide(Number(dot.dataset.slide)));
  });
}

// 筛选功能：谱系图与相册
const filterButtons = Array.from(document.querySelectorAll('.filter-chip'));
const pedigreeNodes = Array.from(document.querySelectorAll('.tree-node'));
const memberCards = Array.from(document.querySelectorAll('.member-card'));
const galleryCards = Array.from(document.querySelectorAll('.gallery-card'));

function applyFilters(activeFilter, items, dataAttribute) {
  items.forEach((item) => {
    const type = item.dataset[dataAttribute] || '';
    const status = item.dataset.status || '';
    const matches = activeFilter === 'all' || type === activeFilter || status === activeFilter;
    item.classList.toggle('is-hidden', !matches);
  });
}

filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    filterButtons.forEach((btn) => btn.classList.remove('active'));
    button.classList.add('active');
    const activeFilter = button.dataset.filter || 'all';
    applyFilters(activeFilter, pedigreeNodes, 'type');
    applyFilters(activeFilter, memberCards, 'type');
    applyFilters(activeFilter, galleryCards, 'tag');
  });
});

// 切换个人主页 Tab
const tabButtons = Array.from(document.querySelectorAll('.tab-button'));
const tabPanels = Array.from(document.querySelectorAll('.tab-panel'));

tabButtons.forEach((button) => {
  button.addEventListener('click', () => {
    tabButtons.forEach((btn) => btn.classList.remove('active'));
    tabPanels.forEach((panel) => panel.classList.remove('active'));
    button.classList.add('active');
    const target = button.dataset.tab;
    const panel = document.querySelector(`[data-panel="${target}"]`);
    if (panel) {
      panel.classList.add('active');
    }
  });
});

// 模态框：相册预览
const galleryItems = Array.from(document.querySelectorAll('.gallery-card'));
const modal = document.querySelector('[data-modal]');
const modalImage = document.querySelector('[data-modal-image]');

if (galleryItems.length && modal && modalImage) {
  galleryItems.forEach((item) => {
    item.addEventListener('click', () => {
      modal.classList.remove('hidden');
      modal.classList.add('flex');
      modalImage.src = item.querySelector('img').src;
    });
  });

  modal.addEventListener('click', (event) => {
    if (event.target === modal) {
      modal.classList.add('hidden');
      modal.classList.remove('flex');
    }
  });
}

// 工具页：DPS 计算器
const calcForm = document.getElementById('calc-form');
const calcResult = document.getElementById('calc-result');
const barBase = document.getElementById('bar-base');
const barFinal = document.getElementById('bar-final');

if (calcForm && calcResult) {
  calcForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const attack = Number(document.getElementById('attack').value) || 0;
    const breakDef = Number(document.getElementById('break').value) || 0;
    const crit = Number(document.getElementById('crit').value) || 0;
    const eff = Number(document.getElementById('eff').value) || 0;
    const double = Number(document.getElementById('double').value) || 0;
    const skill = Number(document.getElementById('skill').value) || 0;

    const baseDps = attack * (1 + breakDef / 100) * (1 + crit / 100 + eff / 100);
    const finalDps = baseDps * skill * (1 + double / 100);

    calcResult.textContent = `${Math.round(finalDps).toLocaleString()} DPS`;
    if (barBase && barFinal) {
      barBase.style.width = `${Math.min(100, Math.round((baseDps / 40000) * 100))}%`;
      barFinal.style.width = `${Math.min(100, Math.round((finalDps / 40000) * 100))}%`;
    }
  });
}

// 宏编辑器按钮
const macroEditor = document.getElementById('macro-editor');
const copyBtn = document.getElementById('copy-macro');
const formatBtn = document.getElementById('format-macro');

if (copyBtn && macroEditor) {
  copyBtn.addEventListener('click', async () => {
    await navigator.clipboard.writeText(macroEditor.value);
    copyBtn.textContent = '已复制';
    setTimeout(() => {
      copyBtn.textContent = '一键复制';
    }, 1200);
  });
}

if (formatBtn && macroEditor) {
  formatBtn.addEventListener('click', () => {
    const lines = macroEditor.value.split('\n').filter(Boolean).map((line) => line.trim());
    macroEditor.value = lines.join('\n');
  });
}
